vla_zoo runtime report bundle

Open dashboard.html in a browser first. records.json contains the normalized dashboard records. metadata.json contains adapter inventory and input paths. Original inputs are copied under inputs/.
